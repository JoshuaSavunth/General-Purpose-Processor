LIBRARY ieee;
USE ieee.std_logic_1164.all;
USE ieee.std_logic_unsigned.all;

ENTITY sseg2 IS
	PORT (bcd :IN STD_LOGIC;
			leds:OUT STD_LOGIC_VECTOR(1 TO 7));
END sseg2;

ARCHITECTURE Behavior OF sseg2 IS
BEGIN
	WITH bcd SELECT ---abcdefg
		  leds	<=	  "1000010" WHEN '1', --1
						  "1101010" WHEN OTHERS;
END Behavior;
